from django.shortcuts import render
from .models import Reservation
from django.shortcuts import render, redirect
from .forms import ReservationForm
from django.contrib.auth.views import LoginView
from .forms import CustomAuthenticationForm
from django.urls import reverse_lazy
from django.views import generic
from .forms import SignUpForm

class SignUpView(generic.CreateView):
    form_class = SignUpForm
    success_url = reverse_lazy('login')  # Rediriger vers la page de connexion après l'inscription
    template_name = 'app_info/signup.html'


class CustomLoginView(LoginView):
    form_class = CustomAuthenticationForm
    template_name = 'app_info/Login.html'
    redirect_authenticated_user = False  # Rediriger les utilisateurs déjà connectés

    def get_success_url(self):
        return self.request.GET.get('next', '/')  # Rediriger vers la page d'accueil par défaut après la connexion


def calendrier_reservations(request):
    reservations = Reservation.objects.all()
    return render(request, 'app_info/calendrier.html', {'reservations': reservations})

def ajouter_reservation(request):
    if request.method == 'POST':
        form = ReservationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('calendrier_reservations')
    else:
        form = ReservationForm()
    return render(request, 'app_info/ajouter_reservation.html', {'form': form})